Copyright 2001 (c) David C. Druffner 
ddruff@gemini1consulting.com
********************************************************************************
This tar.gz file should contain the following files:

phptidyht.php			The main script
phptidyht_demo.php		A demo script
readme.txt			This file
phptidyht_manual_big.html 	Manual in Single Html File

phpTidyHt can be downloaded from phptidyht.sourceforge.net
and www.gemini1consulting.com/tekhelp

An online manual where you can post comments is available at:
http://www.gemini1consulting.com/tekhelp/online_manuals/phptidyht/

The manual in various formats can be downloaded from:
http://www.gemini1consulting.com/tekhelp/phptidyht/docs/

************
* LICENSE: *
************
The phpTidyHt.php script contains the following license:  Redistribution and
use in source and binary forms, with or without modification,  are permitted
provided that the following conditions are met: 

1.Redistributions of source code must retain the above copyright notice, this
list  of conditions and the following disclaimer. 

2.Redistributions in binary form must reproduce the above copyright notice,
this list  of conditions and the following disclaimer in the documentation
and/or other materials  provided with the distribution. 

3.The name of the author may not be used to endorse or promote products
derived from  this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
EVENT SHALL THE AUTHOR, ANY DISTRIBUTOR, OR ANY DOWNLOAD HOSTING COMPANY BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.  


